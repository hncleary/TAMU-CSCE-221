# This is the some sample code for CSCE 221. You will violate Aggie Honor Code by submitting it as your homework. 

