#include "BTree.h"
#include <iostream>
#include <fstream>

template<typename T>
BTree<T> read_file(string file_name);

using namespace std;

int main()
{
	BTree<int> new_tree = read_file<int>("");
}

template<typename T>
BTree<T> read_file(string file_name)
{
    /*
        open the file and use the input operator (operator>>)
        to construct a new tree
    */
    BTree<T> new_tree;
    return new_tree;
}
